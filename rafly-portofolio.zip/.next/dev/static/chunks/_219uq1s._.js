(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0d3rj1o._.css","static/chunks/node_modules_0zeefz5._.js","static/chunks/_023mpqa._.js","static/chunks/node_modules_next_dist_0t9mxq6._.js","static/chunks/components_05mmzs-._.js"],
    source: "entry"
});
