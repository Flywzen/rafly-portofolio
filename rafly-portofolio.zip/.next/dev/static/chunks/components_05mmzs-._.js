(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/DistortImage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DistortImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/animejs/lib/anime.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/motion.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function DistortImage({ children, className, ...rest }) {
    _s();
    const filterId = `distort-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])().replace(/:/g, '')}`;
    const displacementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const state = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        scale: 0
    });
    const animateTo = (target, duration)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            targets: state.current,
            scale: target,
            duration,
            easing: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASE_OUT"],
            update: ()=>{
                displacementRef.current?.setAttribute('scale', String(state.current.scale));
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            targets: contentRef.current,
            scale: target > 0 ? 1.06 : 1,
            duration,
            easing: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASE_OUT"]
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative overflow-hidden ${className ?? ''}`,
        onMouseEnter: ()=>animateTo(55, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DURATION"].slow),
        onMouseLeave: ()=>animateTo(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DURATION"].base),
        ...rest,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                width: "0",
                height: "0",
                className: "absolute",
                "aria-hidden": "true",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("filter", {
                        id: filterId,
                        x: "-20%",
                        y: "-20%",
                        width: "140%",
                        height: "140%",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feTurbulence", {
                                type: "fractalNoise",
                                baseFrequency: "0.01 0.04",
                                numOctaves: 2,
                                seed: 3,
                                result: "noise"
                            }, void 0, false, {
                                fileName: "[project]/components/DistortImage.tsx",
                                lineNumber: 62,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("feDisplacementMap", {
                                ref: displacementRef,
                                in: "SourceGraphic",
                                in2: "noise",
                                scale: 0,
                                xChannelSelector: "R",
                                yChannelSelector: "G"
                            }, void 0, false, {
                                fileName: "[project]/components/DistortImage.tsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/DistortImage.tsx",
                        lineNumber: 61,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/DistortImage.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/DistortImage.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: contentRef,
                style: {
                    filter: `url(#${filterId})`,
                    willChange: 'transform'
                },
                className: "w-full h-full",
                children: children
            }, void 0, false, {
                fileName: "[project]/components/DistortImage.tsx",
                lineNumber: 67,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/DistortImage.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_s(DistortImage, "4mxZujFJSfzrlaQNp8jvwfpQNRM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = DistortImage;
var _c;
__turbopack_context__.k.register(_c, "DistortImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ExpandPanel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExpandPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/animejs/lib/anime.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/motion.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function ExpandPanel({ id, collapsedTrigger, expandedTrigger, triggerClassName, panelClassName, children, defaultExpanded = false }) {
    _s();
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultExpanded);
    const [rendered, setRendered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultExpanded);
    const panelRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ExpandPanel.useEffect": ()=>{
            const panel = panelRef.current;
            if (!panel) return;
            const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            if (expanded) {
                setRendered(true);
                // Wait a frame so the panel has its natural content height to measure.
                requestAnimationFrame({
                    "ExpandPanel.useEffect": ()=>{
                        const target = panelRef.current;
                        if (!target) return;
                        const height = target.scrollHeight;
                        if (reduceMotion) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].set(target, {
                                height,
                                opacity: 1
                            });
                            return;
                        }
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                            targets: target,
                            height: [
                                0,
                                height
                            ],
                            opacity: [
                                0,
                                1
                            ],
                            duration: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DURATION"].base,
                            easing: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASE_OUT"],
                            complete: {
                                "ExpandPanel.useEffect": ()=>{
                                    target.style.height = 'auto';
                                }
                            }["ExpandPanel.useEffect"]
                        });
                    }
                }["ExpandPanel.useEffect"]);
            } else if (rendered) {
                const height = panel.scrollHeight;
                if (reduceMotion) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].set(panel, {
                        height: 0,
                        opacity: 0
                    });
                    setRendered(false);
                    return;
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    targets: panel,
                    height: [
                        height,
                        0
                    ],
                    opacity: [
                        1,
                        0
                    ],
                    duration: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DURATION"].base,
                    easing: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASE_OUT"],
                    complete: {
                        "ExpandPanel.useEffect": ()=>setRendered(false)
                    }["ExpandPanel.useEffect"]
                });
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["ExpandPanel.useEffect"], [
        expanded
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>setExpanded((p)=>!p),
                "aria-expanded": expanded,
                "aria-controls": id,
                className: triggerClassName,
                children: expanded ? expandedTrigger : collapsedTrigger
            }, void 0, false, {
                fileName: "[project]/components/ExpandPanel.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            rendered && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: id,
                ref: panelRef,
                className: panelClassName,
                style: {
                    height: 0,
                    opacity: 0,
                    overflow: 'hidden'
                },
                children: children
            }, void 0, false, {
                fileName: "[project]/components/ExpandPanel.tsx",
                lineNumber: 95,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ExpandPanel.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_s(ExpandPanel, "jvBslcb+jzHEMGcH5/F7BS8/bfA=");
_c = ExpandPanel;
var _c;
__turbopack_context__.k.register(_c, "ExpandPanel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Reveal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RevealGroup",
    ()=>RevealGroup,
    "RevealItem",
    ()=>RevealItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/animejs/lib/anime.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/motion.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
/**
 * Scroll-triggered reveal, powered by anime.js + IntersectionObserver.
 *
 * Kept the same public API as the previous framer-motion version
 * (RevealGroup / RevealItem) on purpose: every section that already
 * consumes this (HeroSection, FeaturedProjects, CybersecuritySection, …)
 * needed zero changes when the animation engine underneath was swapped.
 *
 * RevealGroup registers its children via context and fires one
 * anime.timeline() with staggered targets once the group scrolls into
 * view — a single timeline reads as more coordinated than N independent
 * animations racing each other, and it's the anime.js-native way to do
 * what framer's `staggerChildren` did declaratively.
 */ const RevealGroupContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function RevealGroup({ children, className, stagger = 0.08 }) {
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const itemsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const played = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const register = (el)=>{
        if (!itemsRef.current.includes(el)) itemsRef.current.push(el);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RevealGroup.useEffect": ()=>{
            const container = containerRef.current;
            if (!container) return;
            const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            const play = {
                "RevealGroup.useEffect.play": ()=>{
                    if (played.current) return;
                    played.current = true;
                    const targets = itemsRef.current;
                    if (reduceMotion) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].set(targets, {
                            opacity: 1,
                            translateY: 0
                        });
                        return;
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].timeline({
                        easing: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASE_OUT"]
                    }).add({
                        targets,
                        opacity: [
                            0,
                            1
                        ],
                        translateY: [
                            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REVEAL_DISTANCE"],
                            0
                        ],
                        duration: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DURATION"].slow,
                        delay: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].stagger(stagger * 1000)
                    });
                }
            }["RevealGroup.useEffect.play"];
            const observer = new IntersectionObserver({
                "RevealGroup.useEffect": ([entry])=>{
                    if (entry.isIntersecting) play();
                }
            }["RevealGroup.useEffect"], {
                threshold: 0,
                rootMargin: '-80px 0px -80px 0px'
            });
            observer.observe(container);
            return ({
                "RevealGroup.useEffect": ()=>observer.disconnect()
            })["RevealGroup.useEffect"];
        }
    }["RevealGroup.useEffect"], [
        stagger
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RevealGroupContext.Provider, {
            value: {
                register
            },
            children: children
        }, void 0, false, {
            fileName: "[project]/components/Reveal.tsx",
            lineNumber: 81,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/Reveal.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, this);
}
_s(RevealGroup, "qNhCqFvvcVSjof2Dtn3k/DZiKiY=");
_c = RevealGroup;
function RevealItem({ children, className }) {
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(RevealGroupContext);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RevealItem.useEffect": ()=>{
            if (ref.current && ctx) ctx.register(ref.current);
        }
    }["RevealItem.useEffect"], [
        ctx
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: className,
        style: {
            opacity: 0,
            transform: `translateY(${__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REVEAL_DISTANCE"]}px)`
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/components/Reveal.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
_s1(RevealItem, "OCG+VQUnO5os2qvQ86Nzy18oeQQ=");
_c1 = RevealItem;
var _c, _c1;
__turbopack_context__.k.register(_c, "RevealGroup");
__turbopack_context__.k.register(_c1, "RevealItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/SignalCorners.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SignalCorners
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/animejs/lib/anime.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/motion.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function SignalCorners() {
    _s();
    const wrapperRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const cornersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const setCorner = (el)=>{
        if (el && !cornersRef.current.includes(el)) cornersRef.current.push(el);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SignalCorners.useEffect": ()=>{
            const parent = wrapperRef.current?.parentElement;
            if (!parent) return;
            const play = {
                "SignalCorners.useEffect.play": (show)=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                        targets: cornersRef.current,
                        opacity: show ? [
                            0,
                            1
                        ] : [
                            1,
                            0
                        ],
                        scale: show ? [
                            0.3,
                            1
                        ] : [
                            1,
                            0.3
                        ],
                        duration: show ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DURATION"].base : __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DURATION"].fast,
                        easing: show ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$motion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EASE_ELASTIC"] : 'easeInQuad',
                        delay: show ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$animejs$2f$lib$2f$anime$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].stagger(30) : 0
                    });
                }
            }["SignalCorners.useEffect.play"];
            const onEnter = {
                "SignalCorners.useEffect.onEnter": ()=>play(true)
            }["SignalCorners.useEffect.onEnter"];
            const onLeave = {
                "SignalCorners.useEffect.onLeave": ()=>play(false)
            }["SignalCorners.useEffect.onLeave"];
            parent.addEventListener('mouseenter', onEnter);
            parent.addEventListener('mouseleave', onLeave);
            parent.addEventListener('focusin', onEnter);
            parent.addEventListener('focusout', onLeave);
            return ({
                "SignalCorners.useEffect": ()=>{
                    parent.removeEventListener('mouseenter', onEnter);
                    parent.removeEventListener('mouseleave', onLeave);
                    parent.removeEventListener('focusin', onEnter);
                    parent.removeEventListener('focusout', onLeave);
                }
            })["SignalCorners.useEffect"];
        }
    }["SignalCorners.useEffect"], []);
    const corner = 'absolute w-2 h-2 bg-accent opacity-0 pointer-events-none';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: wrapperRef,
        className: "contents",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "aria-hidden": "true",
                ref: setCorner,
                className: `${corner} -top-[3px] -left-[3px]`
            }, void 0, false, {
                fileName: "[project]/components/SignalCorners.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "aria-hidden": "true",
                ref: setCorner,
                className: `${corner} -top-[3px] -right-[3px]`
            }, void 0, false, {
                fileName: "[project]/components/SignalCorners.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "aria-hidden": "true",
                ref: setCorner,
                className: `${corner} -bottom-[3px] -left-[3px]`
            }, void 0, false, {
                fileName: "[project]/components/SignalCorners.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "aria-hidden": "true",
                ref: setCorner,
                className: `${corner} -bottom-[3px] -right-[3px]`
            }, void 0, false, {
                fileName: "[project]/components/SignalCorners.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/SignalCorners.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_s(SignalCorners, "r10yac70STrF5RINb73brrgxEAI=");
_c = SignalCorners;
var _c;
__turbopack_context__.k.register(_c, "SignalCorners");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/SignatureSpiral.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SignatureSpiral
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
/**
 * SignatureSpiral — the one deliberately-visible piece in this system.
 *
 * Everything in BackgroundSystem is generic and meant to go unnoticed.
 * This is the opposite on purpose: a personal signature, not atmosphere.
 * Rafly picked "always iterating, never truly finished" as the trait
 * that describes him as a developer — a spiral fits that literally, not
 * just decoratively: it has no closing point by construction, and how
 * much of it you see is tied to how far you've scrolled through the
 * portfolio, so it never presents itself as "complete" either.
 *
 * Scroll drives the number of visible coils (more of the page seen, more
 * of the spiral revealed). Dragging independently rotates the whole
 * shape — a small tactile extra, layered on top rather than replacing
 * the scroll link.
 *
 * Hidden below `lg` — this is a hero flourish, not something worth
 * fighting for space with the headline on a phone screen.
 */ const CX = 200;
const CY = 200;
const MIN_TURNS = 1.4;
const MAX_TURNS = 5.6;
const MID_TURNS = (MIN_TURNS + MAX_TURNS) / 2;
function spiralPath(turns) {
    const steps = 220;
    let d = '';
    for(let i = 0; i <= steps; i++){
        const angle = i / steps * turns * Math.PI * 2;
        const r = 6 + i / steps * 26 * turns;
        const x = CX + r * Math.cos(angle);
        const y = CY + r * Math.sin(angle);
        d += (i === 0 ? 'M' : 'L') + x.toFixed(1) + ',' + y.toFixed(1) + ' ';
    }
    return d;
}
function SignatureSpiral() {
    _s();
    const pathRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const groupRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const wrapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const rotation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const dragging = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const lastX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const ticking = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const [reduced, setReduced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Respect prefers-reduced-motion: no scroll-linked redraw, no breathing
    // opacity, just a static spiral sitting at a fixed, representative turn
    // count. Dragging still works — it's a discrete user action, not
    // autoplaying motion.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SignatureSpiral.useEffect": ()=>{
            const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
            setReduced(mq.matches);
        }
    }["SignatureSpiral.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SignatureSpiral.useEffect": ()=>{
            if (reduced) {
                pathRef.current?.setAttribute('d', spiralPath(MID_TURNS));
                return;
            }
            const updateFromScroll = {
                "SignatureSpiral.useEffect.updateFromScroll": ()=>{
                    const max = document.documentElement.scrollHeight - window.innerHeight;
                    const progress = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
                    pathRef.current?.setAttribute('d', spiralPath(MIN_TURNS + progress * (MAX_TURNS - MIN_TURNS)));
                    ticking.current = false;
                }
            }["SignatureSpiral.useEffect.updateFromScroll"];
            const onScroll = {
                "SignatureSpiral.useEffect.onScroll": ()=>{
                    if (!ticking.current) {
                        ticking.current = true;
                        requestAnimationFrame(updateFromScroll);
                    }
                }
            }["SignatureSpiral.useEffect.onScroll"];
            updateFromScroll();
            window.addEventListener('scroll', onScroll, {
                passive: true
            });
            return ({
                "SignatureSpiral.useEffect": ()=>window.removeEventListener('scroll', onScroll)
            })["SignatureSpiral.useEffect"];
        }
    }["SignatureSpiral.useEffect"], [
        reduced
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SignatureSpiral.useEffect": ()=>{
            const wrap = wrapRef.current;
            const group = groupRef.current;
            if (!wrap || !group) return;
            const onPointerDown = {
                "SignatureSpiral.useEffect.onPointerDown": (e)=>{
                    dragging.current = true;
                    lastX.current = e.clientX;
                    wrap.setPointerCapture(e.pointerId);
                }
            }["SignatureSpiral.useEffect.onPointerDown"];
            const onPointerMove = {
                "SignatureSpiral.useEffect.onPointerMove": (e)=>{
                    if (!dragging.current) return;
                    rotation.current += (e.clientX - lastX.current) * 0.5;
                    group.style.transform = `rotate(${rotation.current}deg)`;
                    lastX.current = e.clientX;
                }
            }["SignatureSpiral.useEffect.onPointerMove"];
            const onPointerUp = {
                "SignatureSpiral.useEffect.onPointerUp": ()=>{
                    dragging.current = false;
                }
            }["SignatureSpiral.useEffect.onPointerUp"];
            wrap.addEventListener('pointerdown', onPointerDown);
            wrap.addEventListener('pointermove', onPointerMove);
            wrap.addEventListener('pointerup', onPointerUp);
            wrap.addEventListener('pointerleave', onPointerUp);
            return ({
                "SignatureSpiral.useEffect": ()=>{
                    wrap.removeEventListener('pointerdown', onPointerDown);
                    wrap.removeEventListener('pointermove', onPointerMove);
                    wrap.removeEventListener('pointerup', onPointerUp);
                    wrap.removeEventListener('pointerleave', onPointerUp);
                }
            })["SignatureSpiral.useEffect"];
        }
    }["SignatureSpiral.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: wrapRef,
        "aria-hidden": "true",
        className: "hidden lg:block absolute right-0 top-1/2 -translate-y-1/2 w-64 h-64 xl:w-80 xl:h-80 cursor-grab active:cursor-grabbing touch-none select-none",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 400 400",
            className: "w-full h-full overflow-visible",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                ref: groupRef,
                style: {
                    transformOrigin: '200px 200px'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    ref: pathRef,
                    className: reduced ? undefined : 'signature-spiral-breathe',
                    stroke: "rgba(243,241,234,0.28)",
                    strokeWidth: "1.5",
                    fill: "none"
                }, void 0, false, {
                    fileName: "[project]/components/SignatureSpiral.tsx",
                    lineNumber: 128,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/SignatureSpiral.tsx",
                lineNumber: 127,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/SignatureSpiral.tsx",
            lineNumber: 126,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/SignatureSpiral.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(SignatureSpiral, "K8AGtR5hT9i2NTI5jx3z9L2fSWQ=");
_c = SignatureSpiral;
var _c;
__turbopack_context__.k.register(_c, "SignatureSpiral");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_05mmzs-._.js.map